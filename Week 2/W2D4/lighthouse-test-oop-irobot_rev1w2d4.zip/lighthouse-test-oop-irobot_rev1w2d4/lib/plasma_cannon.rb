class PlasmaCannon < Weapon

  def initialize
    super('Plasma Cannon', 200, 55)
  end

end