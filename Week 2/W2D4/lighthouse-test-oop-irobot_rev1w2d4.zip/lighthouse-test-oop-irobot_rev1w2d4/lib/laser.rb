class Laser < Weapon

  def initialize
    super('Laser', 125, 25)
  end

end